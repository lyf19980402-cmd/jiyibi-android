# 记一笔 Android v1.0.1

完整 Android 源码工程。采用简洁浅色界面，包含金额数字键盘、记账确认、本月/今年支出概览、月/年统计、趋势柱状图、历史记录与单笔删除。数据仅保存在手机本地，不需要注册账号。

## 本版本

- App 名称：记一笔
- applicationId：`com.luyufan.minimalledger`
- 版本：`1.0.1`（versionCode 2）
- 启动图标：米白色背景、深咖啡色双硬币与人民币符号
- 构建：GitHub Actions + Java 17 + Gradle 8.9

## 在 GitHub 上构建 APK

1. 将 `JiYiBi_Android_Source_v1.0.1.zip` 上传到仓库根目录。
2. 在仓库中创建 `.github/workflows/android.yml`，粘贴本项目附带的 `android.yml` 内容。
3. 打开 GitHub 仓库的 **Actions**，运行 **Build 记一笔 APK**。
4. 构建成功后，在运行记录页面的 **Artifacts** 下载 `jiyibi-android-v1.0.1`，解压后安装 `app-release.apk`。

## 隐私与数据

记账数据保存在 Android 应用本地 SharedPreferences 中。本应用不申请网络、定位或通讯录权限。卸载应用或清除应用数据会删除本机账目。
