package com.luyufan.minimalledger

import android.os.Bundle
import android.content.Context
import android.view.HapticFeedbackConstants
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Backspace
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.math.BigDecimal
import java.text.DecimalFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private val Canvas = Color(0xFFF7F6F3)
private val Ink = Color(0xFF20201E)
private val Muted = Color(0xFF85837F)
private val Hairline = Color(0xFFE6E3DE)
private val KeyFace = Color(0xFFFBFAF8)
private val DarkButton = Color(0xFF292927)
private val CardFace = Color(0xFFF1EFEB)

data class Expense(val id: Long, val cents: Long, val time: Long)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(247, 246, 243)
        window.navigationBarColor = android.graphics.Color.rgb(247, 246, 243)
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            window.decorView.systemUiVisibility =
                android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or
                android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        }
        setContent { LedgerApp() }
    }
}

@Composable
private fun LedgerApp() {
    val context = LocalContext.current
    val view = LocalView.current
    val prefs = remember { context.getSharedPreferences("ledger_data", Context.MODE_PRIVATE) }
    var expenses by remember { mutableStateOf(loadExpenses(prefs)) }
    var amount by remember { mutableStateOf("") }
    var showStats by remember { mutableStateOf(false) }
    var toastMessage by remember { mutableStateOf<String?>(null) }

    fun persist(list: List<Expense>) {
        expenses = list.sortedByDescending { it.time }
        saveExpenses(prefs, expenses)
    }

    BackHandler(enabled = showStats) { showStats = false }

    MaterialTheme(
        colorScheme = lightColorScheme(
            background = Canvas,
            surface = Canvas,
            primary = DarkButton,
            onPrimary = Color.White,
            onBackground = Ink,
            onSurface = Ink
        )
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = Canvas) {
            AnimatedContent(
                targetState = showStats,
                transitionSpec = { fadeIn() togetherWith fadeOut() },
                label = "screen"
            ) { stats ->
                if (stats) {
                    StatisticsScreen(
                        expenses = expenses,
                        onBack = { showStats = false },
                        onDelete = { item -> persist(expenses.filterNot { it.id == item.id }) }
                    )
                } else {
                    EntryScreen(
                        amount = amount,
                        expenses = expenses,
                        onAmountChange = { amount = it },
                        onStats = { showStats = true },
                        onConfirm = {
                            val cents = try {
                                BigDecimal(amount).movePointRight(2).setScale(0, java.math.RoundingMode.HALF_UP).longValueExact()
                            } catch (_: Exception) { 0L }
                            if (cents > 0L) {
                                val item = Expense(System.currentTimeMillis(), cents, System.currentTimeMillis())
                                persist(listOf(item) + expenses)
                                amount = ""
                                view.performHapticFeedback(HapticFeedbackConstants.CONFIRM)
                                toastMessage = "已记录"
                            }
                        },
                        onKey = { key ->
                            view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                            when (key) {
                                "⌫" -> amount = amount.dropLast(1)
                                "." -> if (!amount.contains(".")) amount = if (amount.isEmpty()) "0." else "$amount."
                                else -> {
                                    val decimals = amount.substringAfter(".", "")
                                    if (amount.length < 10 && (!amount.contains(".") || decimals.length < 2)) {
                                        amount = if (amount == "0") key else amount + key
                                    }
                                }
                            }
                        },
                    )
                }
            }
            toastMessage?.let { message ->
                LaunchedEffect(message) {
                    kotlinx.coroutines.delay(1500)
                    toastMessage = null
                }
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.BottomCenter) {
                    Surface(
                        color = Color(0xFF333330),
                        shape = RoundedCornerShape(24.dp),
                        modifier = Modifier.padding(bottom = 28.dp)
                    ) {
                        Text(message, color = Color.White, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 20.dp, vertical = 11.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun EntryScreen(
    amount: String,
    expenses: List<Expense>,
    onAmountChange: (String) -> Unit,
    onStats: () -> Unit,
    onConfirm: () -> Unit,
    onKey: (String) -> Unit
) {
    val now = Calendar.getInstance()
    val monthTotal = expenses.filter { sameMonth(it.time, now) }.sumOf { it.cents }
    val yearTotal = expenses.filter { sameYear(it.time, now) }.sumOf { it.cents }
    Column(
        modifier = Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()
            .padding(horizontal = 25.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().height(42.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("记一笔", fontSize = 17.sp, fontWeight = FontWeight.Medium, color = Ink)
            Spacer(Modifier.weight(1f))
            IconButton(onClick = onStats, modifier = Modifier.size(42.dp)) {
                Icon(Icons.Filled.BarChart, contentDescription = "统计", tint = Ink, modifier = Modifier.size(23.dp))
            }
        }

        Spacer(Modifier.height(35.dp))
        Row(
            modifier = Modifier.fillMaxWidth().height(62.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("¥", fontSize = 25.sp, color = Ink, fontWeight = FontWeight.Light)
            Spacer(Modifier.width(7.dp))
            Text(
                text = if (amount.isEmpty()) "0.00" else amount,
                fontSize = 39.sp,
                lineHeight = 44.sp,
                fontWeight = FontWeight.Light,
                color = Ink,
                textAlign = TextAlign.Center,
                maxLines = 1
            )
            Box(Modifier.padding(start = 3.dp).width(1.dp).height(34.dp).background(Muted.copy(alpha = 0.65f)))
        }

        Spacer(Modifier.height(28.dp))
        val keys = listOf("1","2","3","4","5","6","7","8","9","⌫","0",".")
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            keys.chunked(3).forEach { row ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(13.dp)
                ) {
                    row.forEach { key ->
                        Box(
                            modifier = Modifier.weight(1f).height(43.dp)
                                .shadow(5.dp, RoundedCornerShape(50), ambientColor = Color(0x16000000), spotColor = Color(0x12000000))
                                .background(KeyFace, RoundedCornerShape(50))
                                .clickable { onKey(key) },
                            contentAlignment = Alignment.Center
                        ) {
                            if (key == "⌫") {
                                Icon(Icons.Filled.Backspace, contentDescription = "删除一位", tint = Ink, modifier = Modifier.size(20.dp))
                            } else {
                                Text(key, color = Ink, fontSize = 21.sp, fontWeight = FontWeight.Normal)
                            }
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(24.dp))
        Box(
            modifier = Modifier.fillMaxWidth().height(49.dp)
                .shadow(3.dp, RoundedCornerShape(50))
                .background(DarkButton, RoundedCornerShape(50))
                .clickable { onConfirm() },
            contentAlignment = Alignment.Center
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(17.dp))
                Spacer(Modifier.width(7.dp))
                Text("确认", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Medium)
            }
        }

        Spacer(Modifier.height(24.dp))
        Row(
            modifier = Modifier.fillMaxWidth().background(CardFace, RoundedCornerShape(17.dp)).padding(vertical = 17.dp, horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.Start) {
                Text("本月支出", color = Muted, fontSize = 12.sp)
                Spacer(Modifier.height(5.dp))
                Text(money(monthTotal), color = Ink, fontSize = 18.sp, fontWeight = FontWeight.Medium)
            }
            Box(Modifier.width(1.dp).height(39.dp).background(Hairline))
            Column(Modifier.weight(1f).padding(start = 16.dp), horizontalAlignment = Alignment.Start) {
                Text("今年支出", color = Muted, fontSize = 12.sp)
                Spacer(Modifier.height(5.dp))
                Text(money(yearTotal), color = Ink, fontSize = 18.sp, fontWeight = FontWeight.Medium)
            }
        }
        Spacer(Modifier.weight(1f))
    }
}

@Composable
private fun StatisticsScreen(
    expenses: List<Expense>,
    onBack: () -> Unit,
    onDelete: (Expense) -> Unit
) {
    var mode by remember { mutableStateOf(false) } // false month, true year
    var offset by remember { mutableIntStateOf(0) }
    val cal = Calendar.getInstance().apply {
        if (mode) add(Calendar.YEAR, offset) else add(Calendar.MONTH, offset)
    }
    val title = if (mode) SimpleDateFormat("yyyy年", Locale.CHINA).format(cal.time)
        else SimpleDateFormat("yyyy年M月", Locale.CHINA).format(cal.time)
    val filtered = expenses.filter {
        if (mode) sameYear(it.time, cal) else sameMonth(it.time, cal)
    }
    val total = filtered.sumOf { it.cents }

    Column(
        Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()
            .padding(horizontal = 24.dp, vertical = 12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "返回", tint = Ink) }
            Spacer(Modifier.weight(1f))
            Text("支出统计", fontSize = 17.sp, fontWeight = FontWeight.Medium, color = Ink)
            Spacer(Modifier.weight(1f))
            Box(Modifier.size(48.dp))
        }
        Spacer(Modifier.height(18.dp))
        Row(Modifier.fillMaxWidth().background(CardFace, RoundedCornerShape(50)).padding(4.dp)) {
            listOf("月统计", "年统计").forEachIndexed { index, label ->
                val selected = mode == (index == 1)
                Box(
                    Modifier.weight(1f).height(38.dp)
                        .background(if (selected) Color.White else Color.Transparent, RoundedCornerShape(50))
                        .clickable { mode = index == 1; offset = 0 },
                    contentAlignment = Alignment.Center
                ) {
                    Text(label, color = if (selected) Ink else Muted, fontSize = 14.sp, fontWeight = if (selected) FontWeight.Medium else FontWeight.Normal)
                }
            }
        }
        Spacer(Modifier.height(22.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Text("‹", fontSize = 30.sp, color = Muted, modifier = Modifier.clickable { offset-- }.padding(horizontal = 8.dp))
            Text(title, fontSize = 15.sp, color = Ink, fontWeight = FontWeight.Medium)
            Text("›", fontSize = 30.sp, color = Muted, modifier = Modifier.clickable { if (offset < 0) offset++ }.padding(horizontal = 8.dp))
        }
        Spacer(Modifier.height(12.dp))
        Text("总支出", fontSize = 12.sp, color = Muted)
        Spacer(Modifier.height(4.dp))
        Text(money(total), fontSize = 34.sp, fontWeight = FontWeight.Light, color = Ink)
        Spacer(Modifier.height(24.dp))
        Text(if (mode) "每月支出" else "每日支出", fontSize = 13.sp, color = Muted)
        Spacer(Modifier.height(12.dp))
        val buckets = if (mode) {
            (1..12).map { month ->
                val amount = filtered.filter {
                    Calendar.getInstance().apply { timeInMillis = it.time }.get(Calendar.MONTH) + 1 == month
                }.sumOf { it.cents }
                month.toString() to amount
            }
        } else {
            val days = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
            (1..days).map { day ->
                val amount = filtered.filter {
                    Calendar.getInstance().apply { timeInMillis = it.time }.get(Calendar.DAY_OF_MONTH) == day
                }.sumOf { it.cents }
                day.toString() to amount
            }
        }
        val max = (buckets.maxOfOrNull { it.second } ?: 0L).coerceAtLeast(1L)
        Row(Modifier.fillMaxWidth().height(112.dp), horizontalArrangement = Arrangement.spacedBy(3.dp), verticalAlignment = Alignment.Bottom) {
            buckets.forEach { (_, value) ->
                val h = (value.toFloat() / max * 100f).coerceAtLeast(if (value > 0) 4f else 2f)
                Box(Modifier.weight(1f).height(h.dp).background(if (value > 0) Color(0xFF77746E) else Hairline, RoundedCornerShape(topStart = 3.dp, topEnd = 3.dp)))
            }
        }
        Spacer(Modifier.height(7.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(if (mode) "1月" else "1日", fontSize = 10.sp, color = Muted)
            Text(if (mode) "6月" else "15日", fontSize = 10.sp, color = Muted)
            Text(if (mode) "12月" else "${cal.getActualMaximum(Calendar.DAY_OF_MONTH)}日", fontSize = 10.sp, color = Muted)
        }
        Spacer(Modifier.height(24.dp))
        Divider(color = Hairline)
        Spacer(Modifier.height(14.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("消费记录", fontSize = 15.sp, fontWeight = FontWeight.Medium, color = Ink)
            Spacer(Modifier.weight(1f))
            Text("${filtered.size} 笔", fontSize = 12.sp, color = Muted)
        }
        Spacer(Modifier.height(6.dp))
        if (filtered.isEmpty()) {
            Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                Text("暂无记录", color = Muted, fontSize = 14.sp)
            }
        } else {
            LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(bottom = 16.dp)) {
                items(filtered, key = { it.id }) { item ->
                    Row(
                        Modifier.fillMaxWidth().padding(vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(SimpleDateFormat("MM月dd日  HH:mm", Locale.CHINA).format(Date(item.time)), fontSize = 13.sp, color = Ink)
                        }
                        Text(money(item.cents), fontSize = 16.sp, color = Ink, fontWeight = FontWeight.Medium)
                        Spacer(Modifier.width(8.dp))
                        IconButton(onClick = { onDelete(item) }, modifier = Modifier.size(34.dp)) {
                            Icon(Icons.Filled.DeleteOutline, contentDescription = "删除记录", tint = Muted, modifier = Modifier.size(19.dp))
                        }
                    }
                    Divider(color = Hairline)
                }
            }
        }
    }
}

private fun sameMonth(time: Long, target: Calendar): Boolean {
    val c = Calendar.getInstance().apply { timeInMillis = time }
    return c.get(Calendar.YEAR) == target.get(Calendar.YEAR) && c.get(Calendar.MONTH) == target.get(Calendar.MONTH)
}
private fun sameYear(time: Long, target: Calendar): Boolean {
    val c = Calendar.getInstance().apply { timeInMillis = time }
    return c.get(Calendar.YEAR) == target.get(Calendar.YEAR)
}
private fun money(cents: Long): String {
    val value = BigDecimal.valueOf(cents, 2)
    return "¥" + DecimalFormat("#,##0.00").format(value)
}
private fun loadExpenses(prefs: android.content.SharedPreferences): List<Expense> {
    return try {
        val array = JSONArray(prefs.getString("items", "[]"))
        (0 until array.length()).map { i ->
            val o = array.getJSONObject(i)
            Expense(o.getLong("id"), o.getLong("cents"), o.getLong("time"))
        }.sortedByDescending { it.time }
    } catch (_: Exception) { emptyList() }
}
private fun saveExpenses(prefs: android.content.SharedPreferences, items: List<Expense>) {
    val array = JSONArray()
    items.forEach { item ->
        array.put(JSONObject().put("id", item.id).put("cents", item.cents).put("time", item.time))
    }
    prefs.edit().putString("items", array.toString()).apply()
}
