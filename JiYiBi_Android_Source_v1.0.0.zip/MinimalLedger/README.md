# 记一笔 Android v1.0.0

按用户选定的浅色极简界面实现：顶部“记一笔”和统计入口、居中金额、3×4数字键盘、深色确认按钮、底部本月/今年支出。统计页提供月/年汇总、趋势柱状图、消费明细和单笔删除。

## 手机端生成 APK（无需本地 Android Studio）

1. 在 GitHub 新建一个空仓库，建议命名 `jiyibi-android`。
2. 把本 ZIP 上传到仓库根目录，文件名保持 `JiYiBi_Android_Source_v1.0.0.zip`。
3. 在仓库中新建文件 `.github/workflows/build.yml`，将随 ZIP 一起提供的 `build.yml` 内容完整粘贴进去并提交到 `main`。
4. 打开仓库 **Actions**，运行 **Build Android APK**，等待绿色勾。
5. 在本次运行页面底部 **Artifacts** 下载 `jiyibi-android-v1.0.0`，解压并安装 `app-release.apk`。

## 数据
记录保存在手机本地，不需要注册或联网。删除应用会清除本机记录。应用不申请网络、定位、通讯录权限。
